﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SearchEngine_TrainTicketMachine.Interface;
using TrainTicketMachine_Entites;

namespace SearchEngine_TrainTicketMachine.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TrainTicketMachine : ControllerBase
    {
        string stations = "1.The stations ";
        string characters = "2.The characters ";           
        private readonly ITrainTicketMachine _trainTicketMachine;
        #region constructor injection
        public TrainTicketMachine(ITrainTicketMachine trainTicketMachine)
        {          
            _trainTicketMachine = trainTicketMachine;
        }
        #endregion
        #region Get Stations
        [HttpGet]
        [Route("Get")]
        public string Get(string input)
        {       
            List<searchstation> searchResultList = _trainTicketMachine.GetAllStartedWithName(input);
            if (searchResultList.Count == 0)
            {
                stations = "1.no next characters ";
                characters = "2.no stations";
            }
            else
            {
                foreach (var item in searchResultList)
                {
                    stations += item.station + " ";
                    characters += item.nextCharacter + " ";
                }
            }
            return stations + characters;
        }
        #endregion
    }
}


