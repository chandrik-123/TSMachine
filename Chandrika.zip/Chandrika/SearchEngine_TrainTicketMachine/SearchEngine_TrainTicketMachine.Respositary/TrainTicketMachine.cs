﻿using SearchEngine_TrainTicketMachine.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TrainTicketMachine_Entites;


namespace SearchEngine_TrainTicketMachine.Repositary
{
    public class TrainTicketMachine : ITrainTicketMachine
    {
        cities cities = new cities();
        public List<searchstation> GetAllStartedWithName(string input)
        {
            try
            {
                string[] arraystations = cities.arraystations;
                List<searchstation> searchResultList = new List<searchstation>();
                for (int i = 0; i < arraystations.Length; i++)
                {
                    if (arraystations[i].StartsWith(input))
                    {
                        searchResultList.Add(new searchstation
                        {
                            station = arraystations[i],
                            nextCharacter = GetNextCharacter(arraystations[i], input)
                        });
                    }
                }
                return searchResultList;
            }
            catch
            {
                return Enumerable.Empty<searchstation>().ToList();
            }
        }
        public string[] GetAllStations()
        {
            throw new NotImplementedException();
        }
        public char GetNextCharacter(string reference, string input)
        {
            try
            {
                return reference.Replace(input, String.Empty).ToCharArray().ToList()[0];
            }

            catch
            {
                return (char)0;
            }
        }
    }
}
