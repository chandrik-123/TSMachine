﻿using System;

namespace TrainTicketMachine_Entites
{
    public class searchstation
    {
        public string station { get; set; }
        public char nextCharacter { get; set; }

        public string error { get; set; }
    }
    public class cities
    {
        public String[] arraystations = {  "DARTFORD", "DARTMOUTH", "TOWER HILL", "DERBY", "LIVERPOOL", "LIVERPOOL LIME STREET", "PADDINGTON", "EUSTON", "LONDON BRIDGE", "VICTORIA" };
    }
    }
        


    

